import re

def clean_code(text):
    if not text:
        return ""
    
    # Remove markdown if present
    if "```" in text:
        parts = re.split(r"```(?:python)?", text)
        if len(parts) >= 2:
            text = parts[1]
    
    return text.strip()
