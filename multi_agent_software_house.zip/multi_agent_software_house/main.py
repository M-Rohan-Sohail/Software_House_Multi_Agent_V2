from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage

# Import State and Agents
from state import agentstate
from agents.manager import manager_agent
from agents.planner import planner_agent
from agents.executor import executor_agent
from agents.file_editor import file_editor
from agents.ask_user import ask_user_agent
from agents.conversational import conversational_agent

def create_graph():
    memory = MemorySaver()
    builder = StateGraph(agentstate)

    builder.add_node("manager", manager_agent)
    builder.add_node("planner", planner_agent)
    builder.add_node("executor", executor_agent)
    
    builder.add_node("file_editor", file_editor)
    builder.add_node("ask_user", ask_user_agent)
    builder.add_node("conversation", conversational_agent)

    builder.set_entry_point("manager")

    def router(state):
        return state["next_agent"]

    builder.add_conditional_edges(
        "manager",
        router,
        {
            "web": "planner",
            "chatbot": "planner",
            "agentic": "planner",
            "file_editor": "planner",  
            "unknown": "ask_user",
            "conversation": "conversation"
        }
    )
    
    builder.add_edge("planner", "executor")
    builder.add_edge("executor", END)
    builder.add_edge("ask_user", END)
    builder.add_edge("conversation", END)

    return builder.compile(checkpointer=memory)

def main():
    try:
        graph = create_graph()
    except Exception as e:
        print(f"Error compiling graph: {e}")
        return

    config = {"configurable": {"thread_id": "user_121"}}
    
    print("Welcome to the Modular Multi-Agent Software House.")
    print("Type 'exit' to quit.\n")
    
    while True:
        try:
            query = input("Ask your question: ")
            if query.lower() in ["exit", "quit", "q"]:
                break
                
            if not query.strip():
                continue
                
            result = graph.invoke({"messages": [HumanMessage(content=query)]}, config)
            print("\nFinal Answer:\n")
            print(result.get("result", ""))
            
        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            print(f"\nAn error occurred: {e}")

if __name__ == "__main__":
    main()
