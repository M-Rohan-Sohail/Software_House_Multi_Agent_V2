from typing import TypedDict, Annotated
from langgraph.graph.message import add_messages

class agentstate(TypedDict):
    task: str
    result: str
    next_agent: str
    subtasks: list
    messages: Annotated[list, add_messages]
    generated_code: str
    filename: str
