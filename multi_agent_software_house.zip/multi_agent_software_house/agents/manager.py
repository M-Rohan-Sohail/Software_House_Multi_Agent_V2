from llm import llm

def manager_agent(state):
    query = state["messages"][-1].content
    
    prompt = f"""
You are a manager in a software development company.

Your job is to route the user's request to the correct developer team.

Available developers:

web → builds websites, dashboards, APIs, and web apps  
chatbot → builds conversational bots and dialogue systems  
agentic → builds advanced AI systems such as RAG pipelines, autonomous agents, and multi-agent workflows  
file_editor → edits, modifies, or updates existing code files

Routing rules:

1. If the request involves:
   - RAG, document question answering
   - AI assistants, LLM systems
   - autonomous agents, multi-agent systems
   → respond with: agentic

2. If the request involves:
   - chatbots, conversational bots, dialogue systems
   → respond with: chatbot

3. If the request involves:
   - websites, web apps, dashboards
   - frontend/backend, APIs
   → respond with: web

4. If the user explicitly asks to:
   - edit files
   - modify existing code
   - update scripts
   - or if the user asks to add something to an existing file
   → respond with: file_editor

5. If the message is casual conversation (greetings, chat, news, etc.)
   → respond with: conversation (limited to tech and available agents only )

6. If the request is unclear or unrelated
   → respond with: unknown

Important rule:
If a request involves **AI systems like RAG chatbots**, prioritize **agentic** over chatbot.
If the user wants to GENERATE CODE for a web app, chatbot, or agentic system, route it directly to the respective domain agent (web, chatbot, agentic) - NOT a generic code generator.

User request:
{query}

Respond with ONLY ONE word from:
web
chatbot
agentic
file_editor
conversation
unknown
"""
    response = llm.invoke(prompt)
    
    # Take only the first valid agent from the response
    agent = response.content.strip().lower().split()[0]
    
    # Clean punctuation, just in case
    agent = agent.strip(",. ")
    
    # Optional: validate agent
    if agent not in ["web", "chatbot", "agentic", "unknown", "conversation", "file_editor"]:
         agent = "unknown"
    
    state["next_agent"] = agent
    return state
