import os
from llm import llm
from utils import clean_code

def file_editor(state):
    task_description = state.get("task", "")
    filename = state.get("filename", "")

    if not filename or not os.path.exists(filename):
        return {
            "generated_code": "",
            "result": f"Error: File '{filename}' not found."
        }

    try:
        with open(filename, "r", encoding="utf-8") as f:
            existing_code = f.read()
    except Exception as e:
        return {
            "generated_code": "",
            "result": f"Error reading file {filename}: {str(e)}"
        }

    prompt = f"""
You are an expert code editor.

Your job is to MODIFY existing code with PRECISION based on the provided instructions/modifications.

EDITING MODE RULES (CRITICAL):
1. You MUST return the FULL updated file.
2. You MUST preserve all unchanged code EXACTLY.
3. You MUST ONLY modify the parts required by the task.
4. You MUST NOT add markdown (NO ``` or ```python) at all in your final output, do not add explanations, or comments like "updated code".
5. DO NOT rewrite the whole file unless absolutely required.

TASK / MODIFICATIONS:
{task_description}

---
EXISTING CODE:
{existing_code}
---

Return ONLY the FULL updated code. No backticks. No markdown.
"""
    try:
        response = llm.invoke(prompt)
        updated_code = clean_code(response.content)
    except Exception as e:
        return {
            "generated_code": "",
            "result": f"Error generating updated code: {str(e)}"
        }

    if not updated_code or len(updated_code) < len(existing_code) * 0.3:
        return {
            "generated_code": existing_code,
            "result": "Warning: Model returned incomplete edit. Original file preserved."
        }

    if "python" in updated_code.lower() and len(updated_code.splitlines()) < 5:
        return {
            "generated_code": existing_code,
            "result": "Warning: Invalid edit detected. Original file preserved."
        }

    return {
        "generated_code": updated_code,
        "result": f"File '{filename}' updated intelligently by file_editor."
    }
