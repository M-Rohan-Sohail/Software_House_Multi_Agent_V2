import re
import json
from llm import llm

def planner_agent(state):
    query = state["messages"][-1].content

    prompt = f"""
You are a senior task planner in a software development company.

Your job is to analyze the user's request and break it into the MINIMUM necessary development subtasks.

Each task must be assigned to ONE of the following specialized agents:
web → builds websites, dashboards, APIs, and user interfaces  
chatbot → designs conversational flows and chatbot interaction logic  
agentic → builds AI systems such as RAG pipelines, autonomous agents, multi-agent workflows  
file_editor → modifies existing code files based on user requests

Task Assignment Guidelines:

1. Only create tasks that are **explicitly required** by the user's request.
2. The domain agents (web, chatbot, agentic) are capable of writing code and returning code implementations themselves.
3. If a task requires creating a new code file, assign the task to the respective domain agent and include a `"filename"` key with the intended file name. Example: {{"agent":"web","task":"implement website frontend","filename":"index.html"}}
4. If a task requires editing an existing file, assign it to the respective domain agent to write the new logic AND include an `"edit": true` flag and `"filename": "..."` key. This tells the system to route the sub-agent's output to the file_editor. Example: {{"agent":"chatbot","task":"add error handling to the chatbot script","filename":"chatbot.py","edit":true}}
5. The **file_editor** agent should generally NOT be assigned directly by you, unless the requested changes are purely generic and outside specific domains. Prefer assigning edits to the domain agents with the `"edit": true` flag.
6. Avoid unnecessary decomposition. Prefer 2–4 tasks maximum.
7. Do NOT include explanations outside the JSON.

User request:
{query}

Return ONLY valid JSON in this format:

[
  {{"agent":"agentic","task":"implement RAG pipeline","filename":"rag.py"}},
  {{"agent":"web","task":"edit web interface to add a button","filename":"index.html","edit":true}}
]
"""

    response = llm.invoke(prompt)

    cleaned_content = re.sub(r"```(?:json)?\n?(.*?)\n?```", r"\1", response.content, flags=re.DOTALL).strip()
    
    try:
        subtasks = json.loads(cleaned_content)
    except Exception as e:
        print(f"Failed to parse JSON: {e}")
        subtasks = []
    
    state["subtasks"] = subtasks

    return state
