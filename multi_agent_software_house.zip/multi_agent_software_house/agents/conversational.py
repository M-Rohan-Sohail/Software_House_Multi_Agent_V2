from llm import llm

def conversational_agent(state):
    messages = state["messages"]
    
    prompt = f"""You are a conversation handler for a software house AI system.

Your role is ONLY to handle short casual conversation like greetings.

You must NOT answer general knowledge questions.

If user has tech related questions it must be limited to
- web development
- chatbot development
- agentic AI development

If the user asks something unrelated politely tell the user that this system only supports software development related queries.

Keep responses short.
"""
    
    # Extract only the latest message to avoid list issues if needed, or pass full context
    # LangChain invoke generally takes lists of dicts or BaseMessages. 
    # For a simple instruction, converting to string is safer:
    conversation_history = "\n".join([str(m) for m in messages[-5:]])
    
    response = llm.invoke(f"{prompt}\n\nMESSAGES:\n{conversation_history}")
    state["result"] = response.content
    return state
