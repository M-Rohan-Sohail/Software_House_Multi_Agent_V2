from llm import llm
from utils import clean_code
import os

def chatbot_agent(state):
    query = state.get("task", "")
    messages = state.get("messages", [])
    filename = state.get("filename", "")
    is_edit = state.get("edit", False)
    
    conversation_history = "\n".join([f"{m.type}: {m.content}" for m in messages[-5:]])
    
    existing_code = ""
    if is_edit and filename and os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            existing_code = f.read()
    
    prompt = f"""
You are a professional chatbot developer.

You must follow a STRICT TWO-PHASE WORKFLOW:

Phase 1 (Planning & Information Gathering):
Analyze the user's request. Identify the chatbot's core purpose.
CRITICAL RULES FOR ASKING QUESTIONS:
- Do NOT ask questions if the user has provided the main purpose (e.g., "build a RAG chatbot to read docs and answer questions").
- ALWAYS fallback to the following DEFAULT PARAMETERS unless the user explicitly requests otherwise:
  * Language: Python
  * Framework: LangChain
  * Vector Store: FAISS
  * Document Loader: PyPDFLoader (if documents are mentioned)
  * Deployment: Local script or simple local API
- ONLY ask questions if the request is completely fundamentally vague.
- If you MUST ask questions, prefix your response exactly with "QUESTIONS:" and DO NOT write code yet.

Phase 2 (Coding):
If the core purpose is clear, IMMEDIATELY proceed to Phase 2.
First, output a brief Development Plan.
Then, generate the COMPLETE, EXECUTABLE code for the chatbot project using the default parameters (or user-specified ones).
If this is an EDIT task, output the appropriate code modifications or the updated code block.

---
Task Metadata:
- Filename targeted: {filename}
- Is Edit Task: {is_edit}

User's specific task:
{query}

Recent conversation context:
{conversation_history}

Existing Code (if edit task):
{existing_code}
---
"""
    response = llm.invoke(prompt)
    content = response.content
    
    if content.strip().upper().startswith("QUESTIONS:"):
        state["generated_code"] = ""
        state["result"] = content
    else:
        state["generated_code"] = clean_code(content)
        state["result"] = f"Chatbot Agent Output:\n\n{content}"
        
    return state
