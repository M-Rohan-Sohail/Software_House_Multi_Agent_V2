def ask_user_agent(state):
    state["result"] = """
This request does not match the available developers.

Available services:
• Web Development
• Chatbot Development
• Agentic AI Systems

Please clarify your request.
"""
    return state
