import os
from .web_agent import web_agent
from .chatbot_agent import chatbot_agent
from .agentic_agent import agentic_agent
from .file_editor import file_editor

def executor_agent(state):
    results = []

    for idx, task in enumerate(state.get("subtasks", []), start=1):
        agent = task.get("agent")
        description = task.get("task", "")
        filename = task.get("filename", "")
        is_edit = task.get("edit", False)

        temp_state = {
            "messages": state.get("messages", []),
            "task": description,
            "filename": filename,
            "edit": is_edit,
            "result": "",
            "generated_code": ""
        }

        # ------------------ ROUTING TO DOMAIN AGENTS ------------------
        out = {}
        if agent == "web":
            out = web_agent(temp_state)
        elif agent == "chatbot":
            out = chatbot_agent(temp_state)
        elif agent == "agentic":
            out = agentic_agent(temp_state)
        elif agent == "file_editor":
            # Direct file editor bypass (rarely assigned directly by planner but possible)
            out = file_editor(temp_state)
        else:
            continue

        result_text = out.get("result", "")
        code_str = out.get("generated_code", "")

        # If it's a question from Phase 1, return it directly to the user
        if result_text.strip().upper().startswith("QUESTIONS:"):
            results.append(result_text)
            continue
            
        # If the domain agent generated code
        if code_str:
            if is_edit:
                # Flow for editing an existing file
                # Pass the generated code to file_editor to intelligently apply it
                edit_state = {
                    "task": f"Apply the following modifications intelligently:\n{code_str}",
                    "filename": filename,
                }
                edit_out = file_editor(edit_state)
                final_code = edit_out.get("generated_code", "")
                
                if final_code:
                    with open(filename, "w", encoding="utf-8") as f:
                        f.write(final_code)
                    results.append(edit_out.get("result", ""))
                else:
                    results.append(edit_out.get("result", "Error: File editor returned no code."))
            else:
                # Flow for creating a new file
                if not filename:
                    filename = f"task_{idx}.py"
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(code_str)
                results.append(result_text + f"\n[System: File '{filename}' created and saved.]")
        else:
            if result_text:
                results.append(result_text)

    state["result"] = "\n\n".join(results)
    return state
